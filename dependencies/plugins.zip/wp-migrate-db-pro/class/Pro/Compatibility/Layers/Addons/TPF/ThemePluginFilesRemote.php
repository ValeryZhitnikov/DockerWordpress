<?php

namespace DeliciousBrains\WPMDBTP;

class ThemePluginFilesRemote {
    //Silence is golden.
}
